var canvas = document.getElementById('canvas');
var uploadImage;
var effectImage;

function loadImage() {
  var imageFile = document.getElementById('imageFile');
  uploadImage = new SimpleImage(imageFile);
  effectImage = new SimpleImage(imageFile);

  uploadImage.drawTo(canvas);
  
}

function imageIsUploaded() {
  if (uploadImage == null) {
    return false;
  } else {
    return true;
  }
}

function doGrayscale() {
  if (imageIsUploaded()) { 
    // make image grayscale
    for (var pixel of effectImage.values()) {
      
      var r = pixel.getRed();
      var g = pixel.getGreen();
      var b = pixel.getBlue();
      
      var avg = (r + g + b) / 3;
      pixel.setRed(avg);
      pixel.setGreen(avg); 
      pixel.setBlue(avg);
      
    }
    
    effectImage.drawTo(canvas);
    
  } else {
    // user needs to upload an image first...
    alert("Please upload an image before attempting to add filters.");
  }
  
}

function doRed() {
  
  if (imageIsUploaded()) { 
    // make image grayscale
    for (var pixel of effectImage.values()) {
      
      var r = pixel.getRed();
      var g = pixel.getGreen();
      var b = pixel.getBlue();
      
      var avg = (r + g + b) / 3;
      
      if (avg < 128) {
        pixel.setRed(avg * 2);
        pixel.setGreen(0);
        pixel.setBlue(0);
      } else {
        pixel.setRed(255);
        pixel.setGreen(avg * 2 - 255);
        pixel.setBlue(avg * 2 - 255);
      }
      
    }
    
    effectImage.drawTo(canvas);
    
  } else {
    // user needs to upload an image first...
    alert("Please upload an image before attempting to add filters.");
  }
  
}

function resetImage() {
  if (imageIsUploaded()) { 
    
    uploadImage.drawTo(canvas);
    effectImage = new SimpleImage(uploadImage);
    
  } else {
    alert("There is no image to reset. Please upload an image first.");
  }
}

function doWarp() {
  if (imageIsUploaded()) { 
    // make image grayscale
    
    var warpAmount = 50;
    var imgWidth = effectImage.getWidth()
    
    for (var pixel of effectImage.values()) {
      var x = pixel.getX();
      var y = pixel.getY();
      
      var curWarp = Math.abs(warpAmount * Math.sin(x * (180 / Math.PI)));
     
     if (x < 90 && y < 1) { console.log(curWarp); }
      
      if (y < curWarp) {
        pixel.setAlpha(0);
      } else {
        pixel.setAllFrom(uploadImage.getPixel(x, y - (curWarp)));
      }
      
    }
    
    effectImage.drawTo(canvas);
    
  } else {
    // user needs to upload an image first...
    alert("Please upload an image before attempting to add filters.");
  }
}

function doRainbow() {
   if (imageIsUploaded()) { 
    
     var height = effectImage.getHeight();
     var stripeHeight = height / 7;
    
     for (pixel of effectImage.values()) {
       
       if (pixel.getY() < stripeHeight) {
         makeRed(pixel);
       } else if (pixel.getY() < stripeHeight * 2) {
         makeOrange(pixel);   
       } else if (pixel.getY() < stripeHeight * 3) {
         makeYellow(pixel);   
       } else if (pixel.getY() < stripeHeight * 4) {
         makeGreen(pixel);   
       } else if (pixel.getY() < stripeHeight * 5) {
         makeBlue(pixel);   
       } else if (pixel.getY() < stripeHeight * 6) {
         makeIndigo(pixel);   
       } else {
         makeViolet(pixel);   
       }
       
     }
    effectImage.drawTo(canvas);
    
  } else {
    alert("There is no image to reset. Please upload an image first.");
  }
}

function getAvg(pixel) {
  return (pixel.getRed() + pixel.getGreen() + pixel.getBlue()) / 3;
}

function setPixelValues(pixel, r, g, b) {
  pixel.setRed(r);
  pixel.setGreen(g);
  pixel.setBlue(b);
}

function makeRed(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 2*avg, 0, 0);
  } else {
    setPixelValues(pixel, 255, 2*avg-255, 2*avg-255);
  }
  
}

function makeOrange(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 2*avg, 0.8*avg, 0);
  } else {
    setPixelValues(pixel, 255, 1.2*avg-51, 2*avg-255);
  }
  
}

function makeYellow(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 2*avg, 2*avg, 0);
  } else {
    setPixelValues(pixel, 255, 255, 2*avg-255);
  }
  
}

function makeGreen(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 0, 2*avg, 0);
  } else {
    setPixelValues(pixel, 2*avg-255, 255, 2*avg-255);
  }
  
}

function makeBlue(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 0, 0, 2*avg);
  } else {
    setPixelValues(pixel, 2*avg-255, 2*avg-255, 255);
  }
  
}

function makeIndigo(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 0.8*avg, 0, 2*avg);
  } else {
    setPixelValues(pixel, 1.2*avg-51, 2*avg-255, 255);
  }
  
}

function makeViolet(pixel) {
  
  var avg = getAvg(pixel);
  if (avg < 128) {
    setPixelValues(pixel, 1.6*avg, 0, 1.6*avg);
  } else {
    setPixelValues(pixel, 0.4*avg+153, 2*avg-255, 0.4*avg+153);
  }
  
}

function doBlur() {
  
   if (imageIsUploaded()) { 
    // make image grayscale
    
    for (var pixel of effectImage.values()) {
      
      averageNear(pixel, 5)
      
    }
    
    effectImage.drawTo(canvas);
    
  } else {
    // user needs to upload an image first...
    alert("Please upload an image before attempting to add filters.");
  }
  
}

function averageNear(origPixel, range) {
  
  var x = origPixel.getX();
  var y = origPixel.getY();
  
  var width = effectImage.getWidth();
  var height = effectImage.getHeight()
  
  var start = [x-range, y-range];
  var end = [x + range, y + range];
  
  var avgRed = null;
  var avgBlue = null;
  var avgGreen = null;
  
  for (var i = start[0]; i < end[0]; i++) {
    if (i >= 0 && i < width) {
      for (var j = start[1]; j < end[1]; j++) {
        if (j >= 0 && j < height) {
          var curPix = uploadImage.getPixel(i, j);
          if (avgRed == null) {
            avgRed = curPix.getRed();
          } else {
            avgRed = (avgRed + curPix.getRed())/2;
          }
          
        if (x == 5 && y == 5) {
          console.log (avgGreen + " | " + curPix.getGreen());
        }
          
          if (avgGreen == null) {
            avgGreen = curPix.getGreen();
          } else {
            avgGreen = (avgGreen + curPix.getGreen())/2;
            
          }
          
         
          
          if (avgBlue == null) {
            avgBlue = curPix.getBlue();
          } else {
            avgBlue = (avgBlue + curPix.getBlue())/2;
          }
        }
      }
    }
  }
  
 
  
  setPixelValues(origPixel, avgRed, avgGreen, avgBlue);
}
var image = null;
function check(image){
  if(image==null){
    alert("No image uploaded.");
    return null;
  }
  else{return image;}
}

function upload(){
  var canvas = document.getElementById("c1");
  var i = document.getElementById("upload");
  image = new SimpleImage(i);
  image.drawTo(canvas);
}

function lossy(){
  if(check(image)!=null){
    var nimage = new SimpleImage(image.getWidth(),image.getHeight());
    
    for(var pixel of image.values()){
      var npixel = nimage.getPixel(pixel.getX(),pixel.getY());
      if(Math.random()>0.5){
        npixel.setRed(pixel.getRed());
        npixel.setGreen(pixel.getGreen());
        npixel.setBlue(pixel.getBlue());
      }
      else{
      }
    }
    var canvas = document.getElementById("c1");
    nimage.drawTo(canvas);
  }
}
function blurimage(){
  if(check(image)!=null){
    var nimage = new SimpleImage(image.getWidth(),image.getHeight());
    
    for(var pixel of image.values()){
      var npixel = nimage.getPixel(pixel.getX(),pixel.getY());
      if(Math.random()>0.5){
        npixel.setRed(pixel.getRed());
        npixel.setGreen(pixel.getGreen());
        npixel.setBlue(pixel.getBlue());
      }
      else{
        var spixel = randPixel(pixel,image);
        /*while(isValid(spixel,nimage)==false){
          spixel = randPixel(npixel);
        }*/
        npixel.setRed(spixel.getRed());
        npixel.setGreen(spixel.getGreen());
        npixel.setBlue(spixel.getBlue());
      }
    }
    var canvas = document.getElementById("c1");
    nimage.drawTo(canvas);
  }
}
function randPixel(pixel,image){
  var check=false;
  while(check==false){
    var xshift = Math.round(Math.random()*10);
    if (Math.random()<0.5){
      xshift=xshift*-1;
    }
    var x = pixel.getX()+xshift;

    var yshift = Math.round(Math.random()*10);
    if (Math.random()<0.5){
      yshift=yshift*-1;
    }
    var y = pixel.getY()+yshift;
    if (x>=0 && x<image.getWidth() && y>=0 && y<image.getHeight()){
      check=true;
    }
  }
  var spixel = image.getPixel(x, y);
  return spixel;
}

/*
function isValid(npixel,nimage){
  if(npixel.getX()<nimage.Width()&&npixel.getX()>=0 &&
    npixel.getY()<nimage.Height()&&npixel.getY()>=0){
    return true;
  }
  else{return false;}
}*/

function clearCanvas(){
  var canvas = document.getElementById("c1");
  var context = canvas.getContext("2d");
  context.clearRect(0,0,canvas.width, canvas.height);
  image=null;
}
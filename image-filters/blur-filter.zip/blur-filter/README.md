# Blur Filter

A Pen created on CodePen.io. Original URL: [https://codepen.io/anaysomani05/pen/MWVLGmN](https://codepen.io/anaysomani05/pen/MWVLGmN).

